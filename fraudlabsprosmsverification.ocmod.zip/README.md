#### Installation

1. Login to the OpenCart admin area.

2. Go to Extensions > Installer and upload this ocmod.zip file.

3. Go to Extensions > Extensions > Anti-Fraud > FraudLabs Pro SMS Verification to install and edit the settings of this extension.

4. Select Enabled. Then enter the FraudLabs Pro API key and other settings.

5. Click on the save button to save the new configuration.

6. Done.

##### Support

This extension has been successfully tested for OpenCart version 3.0.x.

For any sugggestion or issues, kindly submit your feedback to support@fraudlabspro.com