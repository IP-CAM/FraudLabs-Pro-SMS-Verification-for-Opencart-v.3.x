<?php

$_['heading_title']          = 'SMS Verification';
$_['content_empty_data']     = '<div style="background-color:#f8d7da;color:#7d5880;padding:10px;margin-bottom:20px;font-size:1em;"><span>Input data cannot be empty. Verification failed.</span></div>';
$_['content_empty_code']     = '<div style="background-color:#f8d7da;color:#7d5880;padding:10px;margin-bottom:20px;font-size:1em;"><span>Verification code cannot be empty. Verification failed.</span></div>';
$_['content_invalid_code']   = '<div style="background-color:#f8d7da;color:#7d5880;padding:10px;margin-bottom:20px;font-size:1em;"><span>Invalid verification code. Verification failed.</span></div>';
$_['content_phone_verified'] = '<div style="text-align:center;background-color:#d4edda;color:#2e7769;padding:1.5rem;"><span>Your phone number has been successfully verified. Thank you.</span></div>';