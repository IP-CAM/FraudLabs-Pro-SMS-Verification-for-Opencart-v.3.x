<?php
class ModelExtensionFraudFraudLabsProSmsVerification extends Model {
	public function check($data) {
		return;
	}

}